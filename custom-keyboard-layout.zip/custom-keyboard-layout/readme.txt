sk is the original keyboard layout
sk-new is the modified custom keyboard layout

copy the files somewhere else and then do theese commands to apply the keyboard layout

sudo cp sk-new /usr/share/X11/xkb/symbols/sk
sudo dpkg-reconfigure xkb-data

the new keyboard layout will replace slovak extended backslash
